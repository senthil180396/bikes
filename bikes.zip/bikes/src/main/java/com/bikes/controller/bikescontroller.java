package com.bikes.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller

public class bikescontroller {

	@RequestMapping("/")
	public String showDefault() {
		return "index";
	}
	@RequestMapping("/contactus")
	public String showcontact() {
		return "contact";
	}
	@RequestMapping("/signup")
	public String showsignup() {
		return "signup";
	}
	@RequestMapping("/login")
	public String showlogin() {
		return "login";
	}
	@RequestMapping("/aboutus")
	public String showaboutus() {
		return "aboutus";
	}
	@RequestMapping("/upcome")
	public String showupcome() {
		return "upcome";
	}
}
